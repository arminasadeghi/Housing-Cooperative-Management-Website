





// Library.DDD Usings ----------------------------------------------------------

global using Library.DDD.Core.Authorization.Models.AuthorizeAttribute;
global using Library.DDD.Core.EventBus.Abstractions;
global using Library.DDD.Core.EventBus.EventBusRabbitMQ_NS;
global using Library.DDD.Core.Extentions;
global using Library.DDD.Core.RestEase;
global using Library.DDD.Core.BaseControllers;
global using Library.DDD.Core.Types;
global using Library.DDD.Core.EventBus.Events;




// Asp.Net Usings ---------------------------------------------------------
global using System ;
global using Serilog;
global using Serilog.Sinks.Elasticsearch;
global using System.IdentityModel.Tokens.Jwt;
global using System.Reflection;
global using housingCooperative.Infrastructures.Middlewares;
global using housingCooperative.Services;
global using Consul;
global using MediatR;
global using Microsoft.AspNetCore.Authentication.JwtBearer;
global using Microsoft.OpenApi.Models;
global using Microsoft.AspNetCore.Authorization;
global using Microsoft.AspNetCore.Mvc;
global using Swashbuckle.AspNetCore.SwaggerGen;
global using System.Security.Claims;
global using System.Net;
global using Newtonsoft.Json;
global using housingCooperative;
global using housingCooperative.Infrastructures.HostBuilder;
global using Mapster;
global using Microsoft.AspNetCore.Mvc.Versioning;
global using Microsoft.EntityFrameworkCore;
global using housingCooperative.Dtos;
global using housingCooperative.Infrastructures.Extentions;
global using Library.DDD.DataAccessLayer.DAL;
global using housingCooperative.Infrastructures;

namespace housingCooperative.Infrastructures
{
   
}