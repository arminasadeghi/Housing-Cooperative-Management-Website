using System.ComponentModel;

namespace housingCooperative.Enums
{
    public enum ProjectTypeEnum
    {
        [Description("زمین")]
        Land = 0,
        [Description("آپارتمان")]
        Appartement = 1,
        
    }
}