using System.ComponentModel;

namespace housingCooperative.Enums
{
    public enum GenderEnum
    {
        [Description("مرد")]
        Male = 0,
        [Description("زن")]
        Female = 1
        
    }
}