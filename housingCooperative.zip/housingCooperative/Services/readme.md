# Services


Each Service point ot another microservice as sync communication is used by HTTP Request




# Implementation

For each Service Create an interface like below guidline 

https://github.com/canton7/RestEase

For each Service define configuration of URL , Port and method in appsetting.json

## NamingPattern   


 **I** + **ServiceName** + **Service**

# Example
	
    ITestService.cs