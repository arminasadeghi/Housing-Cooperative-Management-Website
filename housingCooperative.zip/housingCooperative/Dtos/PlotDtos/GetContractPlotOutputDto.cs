namespace housingCooperative.Dtos.PlotDtos
{
    public class GetContractPlotOutputDto
    {
        public string Id { get;  set; }
        public string? Name { get;  set; }
        public long? Meterage { get;  set; }
        public string? Description { get;  set; }
    }
}