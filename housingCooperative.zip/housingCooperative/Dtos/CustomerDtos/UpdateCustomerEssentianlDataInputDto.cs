namespace housingCooperative.Dtos.CustomerDtos
{
    public class UpdateCustomerEssentianlDataInputDto
    {
        public string? FirstName { get;  set; }
        public string? LastName { get;  set; }
        public string NationalId { get;  set; }
    }
}