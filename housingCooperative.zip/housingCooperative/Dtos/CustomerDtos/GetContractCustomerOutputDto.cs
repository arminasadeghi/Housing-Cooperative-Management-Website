namespace housingCooperative.Dtos.CustomerDtos
{
    public class GetContractCustomerOutputDto
    {
        public string Id { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
    }
}