namespace housingCooperative.Dtos.Enums
{
    public enum PaymentStatusEnum
    {
        Success , 
        Faied ,
        Pending
    }
}