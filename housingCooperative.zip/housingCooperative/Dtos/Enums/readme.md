
# Enums 

all the enums of the app go here

each enums should contains Description and value


## NamingPattern   


Enums should end with Enum word

Enums name should be PascalCase

# Example
	
	
	TestEnum.cs


#
	public enum TestEnum
    {

        
        [Description("اول")]   First  =  0  , 
        [Description("دوم")]   Second =  1  , 


    }
