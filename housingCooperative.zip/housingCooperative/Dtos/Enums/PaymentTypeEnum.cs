namespace housingCooperative.Dtos.Enums
{
    public enum PaymentTypeEnum
    {
        Deposit ,
        Withdrawal
    }
}