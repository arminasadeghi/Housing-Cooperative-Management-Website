namespace housingCooperative.Dtos.LandProjectDtos
{
    public class GetContractLandProjectOutputDto
    {
        public string? Id {get; set;}
        public string? Name {get; set;}
        public string? Address {get; set;}
        public string? EngineerName {get; set;}
        public string? Description {get; set;}
    }
}