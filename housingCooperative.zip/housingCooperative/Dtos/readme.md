

# DTOs 

all the dtos of the app go here

for each dtos ralated to specific entity should create a folder

## NamingPattern   


Dtos should end with Dto word

DTOs name should be PascalCase

# Example
	
	
	TestDto.cs



	public class TestDto
    {
        
        public string Name { get; set; }
        public string Phone { get; set; }
    }