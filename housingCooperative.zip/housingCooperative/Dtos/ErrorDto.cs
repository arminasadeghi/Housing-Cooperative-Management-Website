namespace housingCooperative.Dtos
{
    public class ErrorDto
    {

        public int Code { get; set; }
        public string ErrorMessage { get; set; }
        public string PersionDescription { get; set; }
    
    }
}